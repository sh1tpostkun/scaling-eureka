const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
    origin: process.env.NODE_ENV === 'production' 
        ? ['https://sh1tpostkun.web1337.net', 'http://sh1tpostkun.web1337.net'] 
        : '*',
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/music-site')
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Guestbook Schema
const guestbookSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        maxlength: 30
    },
    message: {
        type: String,
        required: true,
        maxlength: 200
    },
    date: {
        type: Date,
        default: Date.now
    }
});

const Guestbook = mongoose.model('Guestbook', guestbookSchema);

// Routes
// Get all guestbook entries
app.get('/api/guestbook', async (req, res) => {
    try {
        const entries = await Guestbook.find().sort({ date: -1 });
        res.json(entries);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch entries' });
    }
});

// Add new guestbook entry
app.post('/api/guestbook', async (req, res) => {
    try {
        const { name, message } = req.body;
        
        if (!name || !message) {
            return res.status(400).json({ error: 'Name and message are required' });
        }
        
        const entry = new Guestbook({
            name: name.trim(),
            message: message.trim()
        });
        
        await entry.save();
        res.status(201).json(entry);
    } catch (error) {
        res.status(500).json({ error: 'Failed to save entry' });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
});
